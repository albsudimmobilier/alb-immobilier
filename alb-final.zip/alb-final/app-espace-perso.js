// app-espace-perso.js - Gestion de l'espace personnel
// Plateforme en construction - onboarding réservé

import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.39.0/dist/module/index.js';

const SUPABASE_URL = 'https://kutbxyinpokebjdemlnq.supabase.co';
const SUPABASE_KEY = 'sb_publishable_wXbJu1TP2jZ05TcuMOut9Q_NcumnpIQ';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Espace personnel en construction
console.log('Espace perso - Under construction');

// Les inscriptions ouvriront le 27 juillet 2026
// Pour le moment, voir contact@albimmobilier.fr pour programme bêta
