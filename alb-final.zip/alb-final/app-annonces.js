// app-annonces.js - Gestion des annonces
// Plateforme en construction - logique basique réservée

import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.39.0/dist/module/index.js';

const SUPABASE_URL = 'https://kutbxyinpokebjdemlnq.supabase.co';
const SUPABASE_KEY = 'sb_publishable_wXbJu1TP2jZ05TcuMOut9Q_NcumnpIQ';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Page en construction
console.log('Annonces page - Under construction');

// Placeholder for future annonces logic
