import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.39.0/dist/module/index.js';

// Supabase Configuration
const SUPABASE_URL = 'https://kutbxyinpokebjdemlnq.supabase.co';
const SUPABASE_KEY = 'sb_publishable_wXbJu1TP2jZ05TcuMOut9Q_NcumnpIQ';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Constants
const ITEMS_PER_PAGE = 10;
let currentPage = 1;
let allPros = [];
let filteredPros = [];

// DOM Elements
const prosGrid = document.getElementById('pros-grid');
const paginationEl = document.getElementById('pagination');
const authModal = document.getElementById('auth-modal');

// Initialize
async function init() {
  try {
    await loadPros();
  } catch (error) {
    console.error('Init error:', error);
    prosGrid.innerHTML = '<p style="grid-column: 1/-1;">Erreur lors du chargement des pros.</p>';
  }
}

// Load Pros
async function loadPros() {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('role', 'pro')
      .eq('statut_verifie', true)
      .order('created_at', { ascending: false });

    if (error) throw error;

    allPros = data || [];
    currentPage = 1;
    filterAndDisplay();
  } catch (error) {
    console.error('Error loading pros:', error);
    prosGrid.innerHTML = '<p>Erreur lors du chargement.</p>';
  }
}

// Filter Pros
function filterAndDisplay() {
  const selectedRoles = getSelectedFilters('.role-filter');
  const selectedZones = getSelectedFilters('.zone-filter');

  filteredPros = allPros.filter(pro => {
    const roleMatch = selectedRoles.length === 0 || selectedRoles.includes(pro.role);
    const zoneMatch = selectedZones.length === 0 || 
      (pro.zones_intervention && pro.zones_intervention.some(z => selectedZones.includes(z)));
    return roleMatch && zoneMatch;
  });

  displayPros();
}

// Get Selected Filters
function getSelectedFilters(selector) {
  return Array.from(document.querySelectorAll(selector))
    .filter(el => el.checked)
    .map(el => el.value);
}

// Display Pros
function displayPros() {
  prosGrid.innerHTML = '';

  if (filteredPros.length === 0) {
    prosGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center;">Aucun professionnel trouvé.</p>';
    paginationEl.innerHTML = '';
    return;
  }

  const start = (currentPage - 1) * ITEMS_PER_PAGE;
  const end = start + ITEMS_PER_PAGE;
  const pagePros = filteredPros.slice(start, end);

  pagePros.forEach(pro => {
    const card = createProCard(pro);
    prosGrid.appendChild(card);
  });

  // Pagination
  const totalPages = Math.ceil(filteredPros.length / ITEMS_PER_PAGE);
  displayPagination(totalPages);
}

// Create Pro Card
function createProCard(pro) {
  const card = document.createElement('div');
  card.className = 'pro-card';

  // Avatar
  const avatar = pro.photo_url || '';
  const initials = pro.prenom && pro.nom 
    ? (pro.prenom[0] + pro.nom[0]).toUpperCase()
    : 'PRO';

  // ALB Approuvé Badge
  const avgRating = pro.rating_moyen || 0;
  const reviewCount = pro.nombre_avis || 0;
  const isApproved = avgRating >= 4.5 && reviewCount >= 5;

  // Status
  const status = pro.disponibilite === 'occupé' ? 'occupe' : 'disponible';
  const statusText = status === 'disponible' ? '✓ Disponible' : '⏱ Occupé';
  const lastUpdate = pro.derniere_mise_a_jour 
    ? new Date(pro.derniere_mise_a_jour).toLocaleDateString('fr-FR')
    : 'N/A';

  card.innerHTML = `
    <div class="pro-header">
      ${avatar ? `<img src="${avatar}" alt="${pro.prenom} ${pro.nom}" class="pro-avatar">` : `<div class="pro-avatar">${initials}</div>`}
      <div class="pro-name">${pro.prenom} ${pro.nom}</div>
      <div class="pro-role">${formatRole(pro.role)}</div>
      <div class="pro-rating">
        <span class="stars">${renderStars(pro.rating_moyen || 0)}</span>
        <span>${(pro.rating_moyen || 0).toFixed(1)} (${pro.nombre_avis || 0} avis)</span>
      </div>
      ${isApproved ? '<div class="badge badge-alb pro-badge">ALB Approuvé</div>' : ''}
    </div>
    <div class="pro-body">
      ${pro.zones_intervention ? `
        <div class="pro-zones">
          ${pro.zones_intervention.map(z => `<span class="zone-tag">${z}</span>`).join('')}
        </div>
      ` : ''}
      
      <div class="pro-status ${status}">
        ${statusText}
      </div>

      ${pro.description ? `<p style="font-size: 0.9rem; color: #666; margin: 10px 0;">${pro.description}</p>` : ''}

      <div class="pro-action">
        <button class="btn btn-primary btn-small" onclick="openContactForm(${pro.id}, '${pro.prenom} ${pro.nom}')">
          Contacter
        </button>
        <button class="btn btn-secondary btn-small" onclick="openProfile(${pro.id})">
          Profil
        </button>
      </div>
    </div>
  `;

  return card;
}

// Render Stars
function renderStars(rating) {
  const stars = Math.round(rating);
  return '⭐'.repeat(stars) + (stars < 5 ? '☆'.repeat(5 - stars) : '');
}

// Format Role
function formatRole(role) {
  const roles = {
    'artisan': 'Artisan',
    'courtier': 'Courtier',
    'agent_immobilier': 'Agent immobilier',
    'mandataire_immobilier': 'Mandataire'
  };
  return roles[role] || role;
}

// Pagination
function displayPagination(totalPages) {
  paginationEl.innerHTML = '';

  for (let i = 1; i <= totalPages; i++) {
    const btn = document.createElement('button');
    btn.textContent = i;
    btn.className = i === currentPage ? 'active' : '';
    btn.onclick = () => {
      currentPage = i;
      displayPros();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    paginationEl.appendChild(btn);
  }
}

// Open Contact Form
function openContactForm(proId, proName) {
  const modal = document.getElementById('auth-modal');
  const form = document.getElementById('auth-form');

  form.innerHTML = `
    <form onsubmit="sendMessage(event, ${proId}, '${proName}')">
      <div class="form-group">
        <label>Votre email</label>
        <input type="email" name="email" required>
      </div>
      <div class="form-group">
        <label>Votre message</label>
        <textarea name="message" required placeholder="Décrivez votre demande..."></textarea>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Envoyer</button>
      <button type="button" class="btn btn-secondary btn-block" style="margin-top: 10px;" onclick="closeAuthModal()">Annuler</button>
    </form>
  `;

  modal.classList.add('active');
}

// Open Profile
function openProfile(proId) {
  window.location.href = `pro-profile.html?id=${proId}`;
}

// Close Auth Modal
function closeAuthModal() {
  authModal.classList.remove('active');
}

// Send Message
async function sendMessage(event, proId, proName) {
  event.preventDefault();

  const email = event.target.email.value;
  const message = event.target.message.value;

  try {
    // TODO: Implement message sending via Supabase
    alert('Message en cours d\'envoi à ' + proName);
    closeAuthModal();
  } catch (error) {
    console.error('Error sending message:', error);
    alert('Erreur lors de l\'envoi');
  }
}

// Filter Event Listeners
document.querySelectorAll('.role-filter, .zone-filter').forEach(el => {
  el.addEventListener('change', filterAndDisplay);
});

// Close modal on background click
authModal.addEventListener('click', (e) => {
  if (e.target === authModal) {
    closeAuthModal();
  }
});

// Initialize on load
window.addEventListener('DOMContentLoaded', init);
