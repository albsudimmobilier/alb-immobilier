# ALB Immobilier

**Plateforme de networking immobilier pour la région Var/PACA**

ALB Immobilier est une plateforme décentralisée où les particuliers contactent librement les professionnels — jamais l'inverse.

## 🚀 Stack technique

- **Frontend:** HTML5 / CSS3 / Vanilla JavaScript
- **Database:** Supabase (PostgreSQL)
- **Hosting:** Vercel
- **Email:** Brevo (transactional) + Zimbra/OVH (professional mailboxes)
- **Auth:** 4-digit code (existing) + Magic link (new)

## 📦 Contenu du projet

```
alb-final/
├── index.html              # Homepage
├── pros.html               # Showcase des professionnels
├── annonces.html           # Listing des annonces
├── espace-perso.html       # Dashboard privé
├── cgu.html                # CGU / Mentions légales
├── confidentialite.html     # Politique RGPD
├── styles.css              # Charte graphique
├── app-pros.js             # Logique pros + auth
├── app-annonces.js         # Gestion annonces
├── app-espace-perso.js     # Dashboard privé
├── .env.example            # Variables d'environnement
├── .gitignore              # Git configuration
└── README.md               # Ce fichier
```

## 🎨 Charte graphique

- **Couleurs:** Pourpre `#4B1A3E` + Doré/Ocre `#B28E3D`
- **Typos:** Playfair Display Bold (titres) + Montserrat (body)
- **Fond:** Crème/clair

## 🔐 Configuration locale

1. Copier `.env.example` → `.env`
2. Remplir avec vos clés Supabase/Brevo

```bash
SUPABASE_URL=https://kutbxyinpokebjdemlnq.supabase.co
SUPABASE_KEY=sb_publishable_wXbJu1TP2jZ05TcuMOut9Q_NcumnpIQ
BREVO_API_KEY=your_brevo_key_here
```

## 📱 Pages principales

| Page | Rôle | État |
|------|------|------|
| `index.html` | Accueil | ✅ Actif |
| `pros.html` | Showcase pros + filtres | ✅ Actif (auth + upload photo) |
| `annonces.html` | Listing annonces | 🚧 En construction |
| `espace-perso.html` | Dashboard privé | 🚧 En construction |

## 🎯 Fonctionnalités

### Authentification
- ✅ Code 4-chiffres pour emails existants
- ✅ Magic link pour nouveaux profils
- ✅ Validation email via Brevo

### Pros
- ✅ Upload photo (Supabase Storage)
- ✅ Filtres par zone (8 zones Var/PACA)
- ✅ Badges "ALB Approuvé" (4.5+ ⭐ + 5+ avis)
- ✅ Statut joignable/occupé
- ✅ Panel admin Joce

### Particuliers
- ✅ Publication d'annonces (modération)
- ✅ Recherche pros
- ✅ Contact direct

## 📋 Notes importantes

- **SIRET placeholder** en CGU/Confidentialité → À remplacer lors de l'enregistrement SASU
- **Brevo setup:** SPF/DKIM/DMARC validés sur `albimmobilier.fr`
- **Storage:** Bucket Supabase `pro-photos` pour avatars
- **RLS:** Toutes les tables ont des règles de sécurité activées
- **Email:** Aliases (artisan@, courtier@, etc.) redirigent vers contact@albimmobilier.fr

## 🚢 Déploiement Vercel

```bash
git push origin main
# → Auto-deploy sur Vercel
```

## 📞 Contact

contact@albimmobilier.fr

---

**Plateforme lancée juillet 2026** | *À la bien, toujours* 🎯
